<?php
    //cek session
    if(!empty($_SESSION['admin'])){
        $query = mysqli_query($config, "SELECT * FROM tbl_instansi");
        while($data = mysqli_fetch_array($query)){
            echo '
                <div class="col s12" id="">
                    <div class="card blue">
                        <div class="card-content">';
                            if(!empty($data['logo'])){
                                echo '<div class="circle left"><img class="logo" src="./upload/'.$data['logo'].'"/></div>';
                            } else {
                                echo '<div class="circle left"><img class="logo" src="./asset/img/logo.png"/></div>';
                            }

                            if(!empty($data['SEKRETARIAT DAERAH'])){
                                echo '<h5 class="ins">'.$data['nama'].'</h5>';
                            } else {
                                echo '<h5 class="ins">SEKRETARIAT DAERAH</h5>';
                            }

                            if(!empty($data['JL Moch Roem No. 1 Kel. Bontang Lestari Kec. Bontang Selatan Kode Pos 75326, Website  www.bontangkota.go.id'])){
                                echo '<p class="almt">'.$data['alamat'].'</p>';
                            } else {
                                echo '<p class="almt">JL Moch Roem No. 1 Kel. Bontang Lestari Kec. Bontang Selatan Kode Pos 75326, Website  www.bontangkota.go.id</p>';
                            }
                            echo '
                        </div>
                    </div>
                </div>';
        }
    } else {
        header("Location: ../");
        die();
    }
?>
